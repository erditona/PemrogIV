package com.example.contact_dio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
