package com.example.ats_1214031

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
